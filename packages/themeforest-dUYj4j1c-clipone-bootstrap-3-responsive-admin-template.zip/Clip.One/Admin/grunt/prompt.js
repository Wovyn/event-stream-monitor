﻿module.exports = {
    setNameNewPageAdmin: {
        options: {
            questions: [
              {
                  config: 'filename',
                  type: 'input',
                  message: 'Set the name of the new page (without the .html extension)',
                  default: 'newpage'
              }
            ]
        }
    }
};






